
const config = {

     baseUrl:"https://node-nf0k.onrender.com/",
    //  baseUrl:"http://localhost:2000/",
};
  
  export default config;